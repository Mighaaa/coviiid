package mustshop.arduino.covide;

public interface DeviceListInterface {
    void delete(int positionReal);
}
